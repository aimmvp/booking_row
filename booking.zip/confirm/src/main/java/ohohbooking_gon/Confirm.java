package ohohbooking_gon;

import javax.persistence.*;
import org.springframework.beans.BeanUtils;
import java.util.List;

@Entity
@Table(name="Confirm_table")
public class Confirm {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    private Long bookingId;
    private String confirmUserId;
    private Date confirmDtm;
    private String status;

    @PostPersist
    public void onPostPersist(){
        ConfirmRequested confirmRequested = new ConfirmRequested();
        BeanUtils.copyProperties(this, confirmRequested);
        confirmRequested.publishAfterCommit();


    }

    @PostUpdate
    public void onPostUpdate(){
        ConfirmCompleted confirmCompleted = new ConfirmCompleted();
        BeanUtils.copyProperties(this, confirmCompleted);
        confirmCompleted.publishAfterCommit();


        ConfirmDenied confirmDenied = new ConfirmDenied();
        BeanUtils.copyProperties(this, confirmDenied);
        confirmDenied.publishAfterCommit();

        //Following code causes dependency to external APIs
        // it is NOT A GOOD PRACTICE. instead, Event-Policy mapping is recommended.

        ohohbooking_gon.external.Booking booking = new ohohbooking_gon.external.Booking();
        // mappings goes here
        ConfirmApplication.applicationContext.getBean(ohohbooking_gon.external.BookingService.class)
            .bookingCancel(booking);


    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Long getBookingId() {
        return bookingId;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }
    public String getConfirmUserId() {
        return confirmUserId;
    }

    public void setConfirmUserId(String confirmUserId) {
        this.confirmUserId = confirmUserId;
    }
    public Date getConfirmDtm() {
        return confirmDtm;
    }

    public void setConfirmDtm(Date confirmDtm) {
        this.confirmDtm = confirmDtm;
    }
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }




}
