package ohohbooking_gon;

import javax.persistence.*;
import org.springframework.beans.BeanUtils;
import java.util.List;

@Entity
@Table(name="Booking_table")
public class Booking {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    private Long roomId;
    private String useStartDtm;
    private String useEndDtm;
    private String userId;

    @PostPersist
    public void onPostPersist(){
        BookingCreated bookingCreated = new BookingCreated();
        BeanUtils.copyProperties(this, bookingCreated);
        bookingCreated.publishAfterCommit();


    }

    @PostUpdate
    public void onPostUpdate(){
        BookingChanged bookingChanged = new BookingChanged();
        BeanUtils.copyProperties(this, bookingChanged);
        bookingChanged.publishAfterCommit();


    }

    @PreRemove
    public void onPreRemove(){
        BookingCanceled bookingCanceled = new BookingCanceled();
        BeanUtils.copyProperties(this, bookingCanceled);
        bookingCanceled.publishAfterCommit();


    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }
    public String getUseStartDtm() {
        return useStartDtm;
    }

    public void setUseStartDtm(String useStartDtm) {
        this.useStartDtm = useStartDtm;
    }
    public String getUseEndDtm() {
        return useEndDtm;
    }

    public void setUseEndDtm(String useEndDtm) {
        this.useEndDtm = useEndDtm;
    }
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }




}
