package ohohbooking_gon;

public class UserChanged extends AbstractEvent {

    private Long id;
    private String name;
    private String emilAddress;

    public UserChanged(){
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getEmilAddress() {
        return emilAddress;
    }

    public void setEmilAddress(String emilAddress) {
        this.emilAddress = emilAddress;
    }
}
