package ohohbooking_gon;

import javax.persistence.*;
import org.springframework.beans.BeanUtils;
import java.util.List;

@Entity
@Table(name="Point_table")
public class Point {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    private Integer point;
    private String status;
    private String changeDtm;

    @PostPersist
    public void onPostPersist(){
        PointCreated pointCreated = new PointCreated();
        BeanUtils.copyProperties(this, pointCreated);
        pointCreated.publishAfterCommit();


    }

    @PostUpdate
    public void onPostUpdate(){
        PointSaved pointSaved = new PointSaved();
        BeanUtils.copyProperties(this, pointSaved);
        pointSaved.publishAfterCommit();


        PointSaved pointSaved = new PointSaved();
        BeanUtils.copyProperties(this, pointSaved);
        pointSaved.publishAfterCommit();


    }

    @PostRemove
    public void onPostRemove(){
        PointDeleted pointDeleted = new PointDeleted();
        BeanUtils.copyProperties(this, pointDeleted);
        pointDeleted.publishAfterCommit();


    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Integer getPoint() {
        return point;
    }

    public void setPoint(Integer point) {
        this.point = point;
    }
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    public String getChangeDtm() {
        return changeDtm;
    }

    public void setChangeDtm(String changeDtm) {
        this.changeDtm = changeDtm;
    }




}
