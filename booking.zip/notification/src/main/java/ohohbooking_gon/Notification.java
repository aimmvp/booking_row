package ohohbooking_gon;

import javax.persistence.*;
import org.springframework.beans.BeanUtils;
import java.util.List;

@Entity
@Table(name="Notification_table")
public class Notification {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    private String content;
    private Date sendDtm;

    @PostPersist
    public void onPostPersist(){
        EmailSent emailSent = new EmailSent();
        BeanUtils.copyProperties(this, emailSent);
        emailSent.publishAfterCommit();


    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
    public Date getSendDtm() {
        return sendDtm;
    }

    public void setSendDtm(Date sendDtm) {
        this.sendDtm = sendDtm;
    }




}
