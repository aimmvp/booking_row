package ohohbooking_gon;

public class EmailSent extends AbstractEvent {

    private Long id;
    private String contents;
    private String sendDtm;
    private String userId;

    public EmailSent(){
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }
    public String getSendDtm() {
        return sendDtm;
    }

    public void setSendDtm(String sendDtm) {
        this.sendDtm = sendDtm;
    }
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
